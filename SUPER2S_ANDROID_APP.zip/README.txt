SUPER 2s — Android-style installable app

This package keeps the tested SUPER 2s index.html unchanged and adds PWA files.

Upload ALL five files to the root of the GitHub Pages repository:
- index.html
- manifest.webmanifest
- sw.js
- icon-192.png
- icon-512.png

Then open the GitHub Pages address on Android. In Chrome, use the browser menu and choose
"Install app" or "Add to Home screen" (wording can vary). The SUPER 2s icon will then open
as an app.

The game still needs an internet connection for Supabase/database features.
