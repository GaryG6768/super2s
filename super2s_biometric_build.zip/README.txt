SUPER 2s BIOMETRIC LOGIN - TEST BUILD

This build is designed to add optional fingerprint/Face ID passkey login while keeping the existing name + 4-digit PIN login as the backup.

IMPORTANT:
- Do NOT replace the live index.html yet.
- First apply the SQL migration and deploy the Edge Function.
- Then upload/open biometric_login_test.html on GitHub Pages and test it.
- The passkey test uses proper server-generated WebAuthn challenges and server-side verification.

Files:
1. passkey_migration.sql - database tables/RLS for passkeys and WebAuthn challenges.
2. passkey_edge_function.ts - Supabase Edge Function source.
3. biometric_login_test.html - standalone test page.

GitHub Pages origin used by this build:
https://garyg6768.github.io
RP ID:
garyg6768.github.io

The live Super 2s index.html is NOT included/changed by this build.
