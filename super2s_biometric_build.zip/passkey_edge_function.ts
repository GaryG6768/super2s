import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
  type WebAuthnCredential,
} from 'npm:@simplewebauthn/server@14.0.0';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const secretKeys = JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')!);
const SUPABASE_SECRET_KEY = secretKeys['default'];
const admin = createClient(SUPABASE_URL, SUPABASE_SECRET_KEY, {
  auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
});

const RP_ID = 'garyg6768.github.io';
const ORIGIN = 'https://garyg6768.github.io';
const RP_NAME = 'SUPER 2s';
const FUNCTION_NAME = 'super2s-passkey';

const cors = {
  'Access-Control-Allow-Origin': ORIGIN,
  'Access-Control-Allow-Headers': 'content-type, apikey, authorization',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: cors });
}

function bytesToBase64Url(bytes: Uint8Array): string {
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function uuidToBytes(uuid: string): Uint8Array {
  const hex = uuid.replace(/-/g, '');
  const out = new Uint8Array(16);
  for (let i = 0; i < 16; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

async function checkPlayer(name: string, pin: string) {
  const { data, error } = await admin.rpc('check_player', { p_name: name, p_pin: pin });
  if (error || !data) throw new Error('Incorrect player name or PIN.');
  return String(data);
}

async function cleanOldChallenges() {
  await admin.from('super2s_webauthn_challenges').delete().lt('expires_at', new Date().toISOString());
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'POST required' }, 405);

  try {
    const body = await req.json();
    const op = String(body.op || '');
    await cleanOldChallenges();

    if (op === 'register_options') {
      const name = String(body.name || '').trim();
      const pin = String(body.pin || '').trim();
      if (name.length < 2 || !/^\d{4}$/.test(pin)) return json({ error: 'Enter your name and 4-digit PIN.' }, 400);

      const playerId = await checkPlayer(name, pin);
      const { data: existing } = await admin
        .from('super2s_passkeys')
        .select('credential_id,transports')
        .eq('player_id', playerId);

      const options = await generateRegistrationOptions({
        rpName: RP_NAME,
        rpID: RP_ID,
        userName: name,
        userID: uuidToBytes(playerId),
        attestationType: 'none',
        excludeCredentials: (existing || []).map((p: any) => ({ id: p.credential_id, transports: p.transports || [] })),
        authenticatorSelection: {
          residentKey: 'required',
          userVerification: 'required',
          authenticatorAttachment: 'platform',
        },
        supportedAlgorithmIDs: [-7, -257],
      });

      const { data: challenge, error } = await admin
        .from('super2s_webauthn_challenges')
        .insert({ challenge: options.challenge, purpose: 'registration', player_id: playerId })
        .select('id')
        .single();
      if (error) throw error;

      return json({ challenge_id: challenge.id, options });
    }

    if (op === 'register_verify') {
      const challengeId = String(body.challenge_id || '');
      const credential = body.credential;
      if (!challengeId || !credential) return json({ error: 'Missing registration response.' }, 400);

      const { data: saved, error: challengeError } = await admin
        .from('super2s_webauthn_challenges')
        .select('*')
        .eq('id', challengeId)
        .eq('purpose', 'registration')
        .maybeSingle();
      if (challengeError || !saved) return json({ error: 'Registration challenge expired. Please try again.' }, 400);

      await admin.from('super2s_webauthn_challenges').delete().eq('id', challengeId);

      const verification = await verifyRegistrationResponse({
        response: credential,
        expectedChallenge: saved.challenge,
        expectedOrigin: ORIGIN,
        expectedRPID: RP_ID,
        requireUserVerification: true,
      });

      if (!verification.verified || !verification.registrationInfo) {
        return json({ error: 'Fingerprint/Face ID registration could not be verified.' }, 400);
      }

      const { credential: registered } = verification.registrationInfo;
      const transports = credential.response?.transports || [];
      const publicKeyBase64 = bytesToBase64Url(registered.publicKey);

      const { error: insertError } = await admin.from('super2s_passkeys').insert({
        player_id: saved.player_id,
        credential_id: registered.id,
        public_key: publicKeyBase64,
        counter: registered.counter,
        transports,
      });
      if (insertError) throw insertError;

      const { data: player } = await admin.from('players').select('id,name').eq('id', saved.player_id).single();
      return json({ verified: true, player_id: player?.id, player_name: player?.name });
    }

    if (op === 'auth_options') {
      const options = await generateAuthenticationOptions({
        rpID: RP_ID,
        userVerification: 'required',
      });

      const { data: challenge, error } = await admin
        .from('super2s_webauthn_challenges')
        .insert({ challenge: options.challenge, purpose: 'authentication' })
        .select('id')
        .single();
      if (error) throw error;

      return json({ challenge_id: challenge.id, options });
    }

    if (op === 'auth_verify') {
      const challengeId = String(body.challenge_id || '');
      const assertion = body.credential;
      if (!challengeId || !assertion) return json({ error: 'Missing authentication response.' }, 400);

      const { data: saved, error: challengeError } = await admin
        .from('super2s_webauthn_challenges')
        .select('*')
        .eq('id', challengeId)
        .eq('purpose', 'authentication')
        .maybeSingle();
      if (challengeError || !saved) return json({ error: 'Authentication challenge expired. Please try again.' }, 400);

      await admin.from('super2s_webauthn_challenges').delete().eq('id', challengeId);

      const credentialId = String(assertion.id || '');
      const { data: stored, error: storedError } = await admin
        .from('super2s_passkeys')
        .select('id,player_id,credential_id,public_key,counter,transports')
        .eq('credential_id', credentialId)
        .maybeSingle();
      if (storedError || !stored) return json({ error: 'That fingerprint/Face ID is not registered for Super 2s.' }, 401);

      const b64 = String(stored.public_key).replace(/-/g, '+').replace(/_/g, '/');
      const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
      const raw = atob(padded);
      const publicKey = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) publicKey[i] = raw.charCodeAt(i);

      const credential: WebAuthnCredential = {
        id: stored.credential_id,
        publicKey,
        counter: Number(stored.counter),
        transports: stored.transports || [],
      };

      const verification = await verifyAuthenticationResponse({
        response: assertion,
        expectedChallenge: saved.challenge,
        expectedOrigin: ORIGIN,
        expectedRPID: RP_ID,
        credential,
        requireUserVerification: true,
      });

      if (!verification.verified) return json({ error: 'Fingerprint/Face ID verification failed.' }, 401);

      await admin
        .from('super2s_passkeys')
        .update({ counter: verification.authenticationInfo.newCounter, last_used_at: new Date().toISOString() })
        .eq('id', stored.id);

      const { data: player } = await admin.from('players').select('id,name').eq('id', stored.player_id).single();
      return json({ verified: true, player_id: player?.id, player_name: player?.name });
    }

    return json({ error: `Unknown operation: ${op}` }, 400);
  } catch (error) {
    console.error(FUNCTION_NAME, error);
    return json({ error: error instanceof Error ? error.message : 'Unexpected server error.' }, 500);
  }
});
